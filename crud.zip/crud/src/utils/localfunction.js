 // var newone = JSON.parse(localStorage.getItem('list_items')|| '[]');
                // if(!newone.includes(addItem)){
                //   newone.push(addItem)
                //   localStorage.setItem("list_items", JSON.stringify(newone));

                // }else{
                //   console.log(addItem + 'already exists')
                // }


                              /*localstorage funcitons*/
    
//    let local = JSON.stringify(lists);
//    localStorage.setItem("mainList",local);
//    let getData = localStorage.getItem("mainList");
//    let get_new_data = JSON.parse(getData);
//    console.log(get_new_data);
//    console.log(local);

              /*localstorage funciton === 2*/


            // useEffect(()=>{
            //    setState(JSON.parse(window.localStorage.getItem('list')));
            // },[])

            //  useEffect(()=>{
            //  window.localStorage.setItem('list',lists);  
            // },[lists])
           
                 /*localstorage funciton === 3*/

                    // var myArray = JSON.parse(localStorage.getItem('articles'));
                    // lists = []
                    // myArray.push(lists);
                    // localStorage.setItem('article',JSON.stringify(lists))
                    // console.log(myArray)

               /*localstorage funciton === 4*/

              //  var existing = localStorage.getItem("myList");
              
              //  existing =  existing ? JSON.parse(existing) : {};

              //  existing[''] = '';
              //   console.log(existing);
              //  localStorage.setItem("myLists",JSON.stringify(existing))
       

