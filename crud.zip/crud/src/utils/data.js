export let listArray = [{
    id :'1',
    name :'Pradeep',
    email :'123@gmail.com',
    number:'9876543210',
    password:'986754',
},
{
    id :'2',
    name :'Deep',
    email :'1234@gmail.com',
    number:'9876543201',
    password:'78654',
}
]