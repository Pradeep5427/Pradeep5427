export const LIST_ITEMS = 'LIST_ITEMS';
export const ADD_ITEM = 'ADD_ITEM';
export const UPDATE_ITEM = 'UPDATE_ITEM';
export const DELETE_ITEM = 'DELETE_ITEM';
// export const STORE_DATA = 'STORE_DATA';